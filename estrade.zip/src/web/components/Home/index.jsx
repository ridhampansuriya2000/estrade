import React from 'react';

const Index = () => {
    return (
        <div>
            Home
        </div>
    );
};

export default Index;
