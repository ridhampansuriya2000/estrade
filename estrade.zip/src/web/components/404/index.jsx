import React from 'react';

const Error = () => {
    return (
        <div>
            PageNot Found
        </div>
    );
};

export default Error;
