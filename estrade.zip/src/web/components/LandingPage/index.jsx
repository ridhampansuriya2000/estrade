import React from 'react';

const Landing = () => {
    return (
        <div>
            LandingPage
        </div>
    );
};

export default Landing;
