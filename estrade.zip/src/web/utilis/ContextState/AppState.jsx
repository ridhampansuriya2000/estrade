export const initialState = {
    loading: false,
    userVerify: false,
};
