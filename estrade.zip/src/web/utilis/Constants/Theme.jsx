import {createTheme} from '@mui/material/styles';

export const THEME = createTheme({
    typography: {
        // "fontFamily": `"Roboto", "Helvetica", "Arial", sans-serif`,
        "fontFamily": 'PoppinsRegular'
    },
});
